# readme

3 VMSS template is provided

vmss.json:      VMSS with public facing LB
vmss_ilb.json:  VMSS with internal LB
vmss_edisk:     VMSS with ephemeral disk