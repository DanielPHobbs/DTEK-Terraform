# Packer

Create nginx image

```
packer inspect lx_nginx.json

packer build lx_nginx.json
```