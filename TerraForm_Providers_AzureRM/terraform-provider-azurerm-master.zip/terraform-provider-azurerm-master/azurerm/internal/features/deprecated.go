package features

// this feature toggle's been removed
// however to ease open PR's this is temporarily kicking around

// nolint: deadcode unused
func SupportsCustomTimeouts() bool {
	return true
}
